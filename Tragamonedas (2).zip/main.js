//estas son las variables para crear el bucle y para añadir el intervalo de tiempo
var cant;
var timer;
var color = 0 ;
var backg;
var att = 0;
var tres = 0;
var times = 0;
var maxnum = 7;
numeromaximo.innerHTML += maxnum;
//Esta es la funcion inicial llamada al presionar el boton jugar
function jugar(){
  if(times == 0)  {
    var sounp = document.getElementById("plays");
    sounp.play();
    var first = document.getElementById("uno");
    var second = document.getElementById("dos");
    var therd = document.getElementById("tres");
    color = 0;
    first.style.background = 'linear-gradient(gray, white, gray)';
    second.style.background = 'linear-gradient(gray, white, gray)';
    therd.style.background = 'linear-gradient(gray, white, gray)';
    clearInterval(backg);
    att++;
    first.style.border = '5px solid black';
    second.style.border = '5px solid black';
    therd.style.border = '5px solid black';
    cant = 0;
    timer = setInterval(change, 80);
  }
  times++;
}
//Esta funcion crea el bucle para poder enviar a la pantalla numeros aleatorios
function change(){
  var first = document.getElementById("uno");
  var second = document.getElementById("dos");
  var therd = document.getElementById("tres");
if (cant == 50){
  times = 0;
  if(color == 0){
 backg = setInterval(back, 250);
 }
 else{
   color = 0 ;
   back();
 }
  first.innerHTML = '<br/>' + Math.round(Math.random() * maxnum);
  clearInterval(timer);
  cant = 0;
  second.innerHTML = '<br/>' + Math.round(Math.random() * maxnum);
  therd.innerHTML = '<br/>' + Math.round(Math.random() * maxnum);
   ligth();
}
else if(cant<50){
  first.innerHTML = '<br/>'+Math.round(Math.random()*maxnum);
  cant++;
  second.innerHTML = '<br/>'+Math.round(Math.random()*maxnum);
  therd.innerHTML = '<br/>'+Math.round(Math.random()*maxnum);
}
}
//Esta funcion, cambia el color del borde de las cajas cuando algunas coinciden
function ligth(){
  var first = document.getElementById("uno");
  var second = document.getElementById("dos");
  var therd = document.getElementById("tres");
if(first.innerHTML == second.innerHTML && first.innerHTML == therd.innerHTML){
  var wint = document.getElementById("win3");
  wint.play();
  tres++;
  first.style.border = "5px solid red";
  second.style.border = "5px solid red";
  therd.style.border = "5px solid red";
}
else if(first.innerHTML == second.innerHTML){
  var wind = document.getElementById("win2");
  wind.play();
  first.style.border = "5px solid blue";
  second.style.border = "5px solid blue";
}
else if(first.innerHTML == therd.innerHTML){
  var wind = document.getElementById("win2");
  wind.play();
  first.style.border = '5px solid blue';
  therd.style.border = '5px solid blue';
}
else if(second.innerHTML == therd.innerHTML){
  var wind = document.getElementById("win2");
  wind.play();
  second.style.border = '5px solid blue';
  therd.style.border = '5px solid blue';
}
}
//Esta se encarga de cambiar el color de fondo de las cajas cuando termine de elegir los numeros
function back(){
  var first = document.getElementById("uno");
  var second = document.getElementById("dos");
  var therd = document.getElementById("tres");
  color++;
  if(color == 1 || color == 3 || color == 5 || color == 7 || color == 9 ){
    first.style.background = 'linear-gradient(white, yellow, white)';
    second.style.background = 'linear-gradient(white, yellow, white)';
    therd.style.background = 'linear-gradient(white, yellow, white)';
    if(color == 10){
      color = 0;
      clearInterval(backg);
    }
  }
  else{
    first.style.background = 'linear-gradient(gray, white, gray)';
    second.style.background = 'linear-gradient(gray, white, gray)';
    therd.style.background = 'linear-gradient(gray, white, gray)';
  }
}
//Esta funcion se encarga de recibir el numero maximo hasta el cual el usuario quiere que llegue el juego
function numbermax(){
  var input = document.getElementById("usernum");
  if(input.value > 5 && input.value < 31){
  numeromaximo.innerHTML = input.value;
  maxnum = input.value;
  }
  else{
    input.value = 5;
    maxnum = input.value;
    numeromaximo.innerHTML = maxnum;
  }
}
function what(){
  alert("Donde dice \" Ingrese el numero\" debes escibir el numero maximo hasta el que quieres que llegue el juego \n Por defecto es 7, el numero que introduzcas debe ser mayor que 5 y menor que 30")
}
